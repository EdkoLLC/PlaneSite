"""Local web server for the PlaneSite user interface (binds to 127.0.0.1 only)."""
import json
import math
import mimetypes
import os
import re
import subprocess
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import numpy as np

from . import __version__, layout as L, project as P, updater
from .pipeline import load_project, save_json, safe_name

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB_DIR = os.path.join(APP_DIR, "web")
RUN_SCRIPT = os.path.join(APP_DIR, "run_pipeline.py")
R0 = 64.0  # metres per screen pixel at zoom 0
IS_WIN = sys.platform == "win32"


def console_python():
    """The console Python for worker processes, named PlaneSite.exe in the installed app so
    Task Manager shows PlaneSite rather than python."""
    d = os.path.dirname(sys.executable)
    for n in ("PlaneSite.exe", "python.exe"):
        p = os.path.join(d, n)
        if IS_WIN and os.path.isfile(p):
            return p
    return sys.executable


def config_dir():
    from . import migrate_from_fieldstitch
    migrate_from_fieldstitch()
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    d = os.path.join(base, "PlaneSite")
    os.makedirs(d, exist_ok=True)
    return d


def default_projects_dir():
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    if not os.path.isdir(docs):
        docs = os.path.expanduser("~")
    return os.path.join(docs, "PlaneSite Projects")


def projects_dir(p=None):
    """The folder new projects go in. A project folder chosen by mistake (one holding a PlaneSite
    project) stands for the folder it sits in, so new projects never land inside another one."""
    p = os.path.normpath((p or "").strip() or S.cfg.get("projects_dir") or default_projects_dir())
    while os.path.dirname(p) != p:
        if os.path.isfile(P.project_file(p)):
            p = os.path.dirname(p)              # a project folder
        elif os.path.isfile(P.project_file(os.path.join(p, os.path.basename(p)))):
            p = os.path.dirname(p)              # a job folder holding a project of the same name
        else:                                   # (D:\Projects\Snowflake\Snowflake, next to PPK, Tiles ...)
            break
    return p


class State:
    def __init__(self):
        self.lock = threading.RLock()
        self.dir = None
        self.proj = None
        self.proc = None
        self.scan = None       # {"done", "total", "folder", "error"}
        self.export = None     # {"done", "total", "current", "frac", "files", "errors", "out_dir"}
        self.publish = None    # {"running", "phase", "part", "parts", "sent", "total", "error", "result", ...}
        self.cfg_path = os.path.join(config_dir(), "config.json")
        try:
            with open(self.cfg_path, "r", encoding="utf-8") as f:
                self.cfg = json.load(f)
        except Exception:
            self.cfg = {"recent": []}
        self.tile_local = threading.local()
        self.origin = None
        self.last_seen = 0.0
        # what the page last said about itself: "visible", "hidden" (a background tab or a covered
        # window, which browsers like Safari stop polling from) or "closed" (the page was closed)
        self.win_state = "visible"

    def save_cfg(self):
        save_json(self.cfg_path, self.cfg)

    def remember(self, d):
        rec = [r for r in self.cfg.get("recent", []) if os.path.normcase(r) != os.path.normcase(d)]
        rec.insert(0, d)
        self.cfg["recent"] = rec[:12]
        self.save_cfg()

    def save(self):
        P.save(self.dir, self.proj)

    # ------------------------------------------------------------ paths & origin
    def outputs(self):
        return L.processing_dir(self.dir)

    def report(self):
        if self.proj and self.proj.get("geotiff"):
            g = self.proj["geotiff"]
            return {"ortho": g["path"], "epsg": g["epsg"], "gsd_cm": g["gsd_cm"], "imported": True,
                    "area_ha": g.get("area_ha")}
        p = os.path.join(self.outputs(), "report.json")
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return None
        return None

    def ortho_path(self):
        if self.proj and self.proj.get("geotiff"):
            p = self.proj["geotiff"]["path"]
            return p if os.path.exists(p) else None
        r = self.report()
        if r:
            p = os.path.join(self.outputs(), r.get("ortho", ""))
            if os.path.exists(p):
                return p
        return None

    def compute_origin(self):
        """Fixed local origin (UTM metres) for the map frame."""
        from .geo import Geo, utm_epsg
        if self.proj.get("map_origin"):
            o = self.proj["map_origin"]
            self.origin = (o["epsg"], o["e"], o["n"])
            return
        photos = [m for m in self.proj["photos"] if m.get("lat") is not None]
        if not photos:
            self.origin = None
            return
        lon = float(np.median([m["lon"] for m in photos]))
        lat = float(np.median([m["lat"] for m in photos]))
        epsg = utm_epsg(lon, lat)
        e, n = Geo(epsg).to_utm(lon, lat)
        self.origin = (epsg, math.floor(e), math.floor(n))
        self.proj["map_origin"] = {"epsg": epsg, "e": self.origin[1], "n": self.origin[2]}
        self.save()

    def running(self):
        return self.proc is not None and self.proc.poll() is None


S = State()


# ------------------------------------------------------------------- helpers
def json_body(handler):
    n = int(handler.headers.get("Content-Length") or 0)
    if n == 0:
        return {}
    return json.loads(handler.rfile.read(n).decode("utf-8"))


class ApiError(Exception):
    pass


def open_in_explorer(path):
    if IS_WIN:
        os.startfile(path)  # noqa
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


BROWSE_CODE = r'''
import sys, tkinter as tk
from tkinter import filedialog
r = tk.Tk(); r.withdraw()
try:
    r.attributes("-topmost", True)
except Exception:
    pass
mode, title, init = sys.argv[1], sys.argv[2], sys.argv[3]
if mode == "folder":
    p = filedialog.askdirectory(parent=r, title=title, initialdir=init or None, mustexist=True)
elif mode == "images":
    ps = filedialog.askopenfilenames(parent=r, title=title, initialdir=init or None,
        filetypes=[("Drone photos", "*.jpg *.jpeg *.JPG *.JPEG"), ("All files", "*.*")])
    p = "\n".join(ps or [])
elif mode == "geotiff":
    p = filedialog.askopenfilename(parent=r, title=title, initialdir=init or None,
        filetypes=[("GeoTIFF", "*.tif *.tiff"), ("All files", "*.*")])
else:
    p = filedialog.askopenfilename(parent=r, title=title, initialdir=init or None,
        filetypes=[("Field boundaries", "*.kml *.kmz *.shp *.geojson *.json"), ("All files", "*.*")])
sys.stdout.write(p or "")
'''


def _mac_browse(mode, title, initial):
    """Native macOS open dialog (AppleScript), shown in front of the PlaneSite window."""
    def q(v):
        return '"' + (v or "").replace("\\", "\\\\").replace('"', '\\"') + '"'
    where = ""
    if initial and os.path.isdir(initial):
        where = " default location (POSIX file %s)" % q(initial)
    types = {"images": '{"public.jpeg"}', "geotiff": '{"public.tiff"}'}.get(mode)
    if mode == "folder":
        body = "set r to choose folder with prompt %s%s\nreturn POSIX path of r" % (q(title), where)
    else:
        multi = " with multiple selections allowed" if mode == "images" else ""
        of_type = (" of type " + types) if types else ""
        body = ("set r to choose file with prompt %s%s%s%s\n" % (q(title), of_type, where, multi) +
                ("set out to \"\"\nrepeat with f in r\nset out to out & POSIX path of f & linefeed\nend repeat\nreturn out"
                 if mode == "images" else "return POSIX path of r"))
    # the dialog belongs to osascript itself (brought to the front), so macOS doesn't ask for
    # permission to control the browser
    script = "activate\n" + body
    out = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=3600)
    return (out.stdout or "").strip() if out.returncode == 0 else ""     # cancelled: error -128


def browse(mode, title, initial):
    if sys.platform == "darwin":
        p = _mac_browse(mode, title, initial)
        if mode == "images":
            return [os.path.normpath(x) for x in p.splitlines() if x.strip()]
        return os.path.normpath(p) if p else ""
    flags = 0x08000000 if IS_WIN else 0
    out = subprocess.run([sys.executable, "-c", BROWSE_CODE, mode, title, initial or ""],
                         capture_output=True, text=True, creationflags=flags, timeout=3600)
    p = (out.stdout or "").strip()
    if mode == "images":
        return [os.path.normpath(x) for x in p.splitlines() if x.strip()]
    return os.path.normpath(p) if p else ""


# ---------------------------------------------------------------- project ops
def project_summary():
    if not S.proj:
        return None
    s = P.summarize(S.proj)
    s.update({"name": S.proj["name"], "dir": S.dir, "folders": S.proj.get("folders", []),
              "settings": S.proj["settings"], "has_result": S.ortho_path() is not None,
              "has_frame": S.origin is not None, "planned": bool(S.proj.get("plan")),
              "frame": "%d_%d_%d" % tuple(S.origin) if S.origin else None,
              "geotiff": (S.proj.get("geotiff") or {}).get("path")})
    return s


def recent_projects():
    out = []
    for d in S.cfg.get("recent", []):
        pf = P.project_file(d)
        if not os.path.exists(pf):
            continue
        name = os.path.basename(d).replace("_", " ")
        try:
            with open(pf, "r", encoding="utf-8") as f:
                head = f.read(4096)
            m = re.search(r'"name":\s*"((?:[^"\\]|\\.)*)"', head)
            if m:
                name = json.loads('"%s"' % m.group(1))
        except Exception:
            pass
        planned = False
        try:
            if os.path.getsize(pf) < 200000:
                with open(pf, "r", encoding="utf-8") as f:
                    pj = json.load(f)
                planned = bool(pj.get("plan")) and not pj.get("photos")
        except Exception:
            pass
        out.append({"dir": d, "name": name, "modified": os.path.getmtime(pf), "planned": planned,
                    "has_result": os.path.exists(os.path.join(L.processing_dir(d), "report.json")),
                    "has_thumb": os.path.exists(os.path.join(L.processing_dir(d), "preview.png"))})
    return out


def open_project(d):
    d = os.path.normpath(d)
    if not os.path.exists(P.project_file(d)):
        raise ApiError("No PlaneSite project in that folder.")
    with S.lock:
        if S.running():
            raise ApiError("Processing is running. Cancel it before switching projects.")
        # 2.0 keeps PlaneSite's own files in "PlaneSite data" so the project folder shows "exports"
        # first; an older project is moved over the first time it's opened (renames, instant)
        moved = L.migrate(d)
        if moved:
            print("Moved %s into '%s' in %s" % (", ".join(moved), L.DATA, d))
        S.dir = d
        S.proj = P.load(d)
        S.origin = None
        S.compute_origin()
        remember_place()
        S.remember(d)
        S.tile_local = threading.local()


def scan_worker(folder, recursive, files=None):
    try:
        known = set(m["path"] for m in S.proj["photos"])

        def prog(done, total):
            S.scan.update(done=done, total=total)

        if files:
            metas, errors = P.scan_paths(files, prog, known)
        else:
            metas, errors = P.scan_folder(folder, recursive, prog, known)
        with S.lock:
            S.proj["photos"].extend(metas)
            S.proj["photos"].sort(key=lambda m: (m.get("time") or 0, m["path"]))
            if folder and folder not in S.proj["folders"]:
                S.proj["folders"].append(folder)
            S.proj["selection"] = None
            if not S.proj.get("plan"):       # a planned job keeps the frame its fields were drawn in
                S.proj.pop("map_origin", None)
            S.compute_origin()
            S.save()
        small = [e for e in errors if e[1].startswith("too small")]
        bad = [e for e in errors if not e[1].startswith("too small")]
        S.scan.update(finished=True, added=len(metas), errors=len(bad), skipped_small=len(small),
                      error_examples=[os.path.basename(e[0]) + ": " + e[1] for e in bad[:3]])
    except Exception as e:
        S.scan.update(finished=True, error=str(e))


def start_scan(folder=None, files=None, recursive=True):
    if S.running():
        raise ApiError("Processing is running.")
    if S.scan and not S.scan.get("finished"):
        raise ApiError("Already reading photos.")
    if files:
        files = [os.path.normpath(f) for f in files if os.path.isfile(f)]
        if not files:
            raise ApiError("None of those files could be found.")
    elif not folder or not os.path.isdir(folder):
        raise ApiError("Folder not found: %s" % folder)
    S.scan = {"done": 0, "total": len(files) if files else 0, "folder": folder or "", "finished": False}
    threading.Thread(target=scan_worker, args=(None if files else folder, recursive, files),
                     daemon=True).start()


def unique_project_dir(parent, name):
    base = safe_name(name)
    d = os.path.join(parent, base)
    k = 2
    while os.path.exists(d):
        d = os.path.join(parent, "%s_%d" % (base, k))
        k += 1
    return d


def name_from_source(folder=None, files=None):
    src = folder
    if files:
        src = os.path.dirname(files[0]) if len(files) == 1 else os.path.commonpath(files)
        if os.path.isfile(src):
            src = os.path.dirname(src)
    src = os.path.normpath(src or "")
    nm = os.path.basename(src)
    # DJI card folders (DCIM, 100MEDIA, DJI_2024...) say little; use the parent folder instead
    while nm and re.match(r"^(DCIM|\d{3}MEDIA|DJI_\d.*|\d{3}[A-Z_]*)$", nm, re.I):
        src = os.path.dirname(src)
        nm = os.path.basename(src)
    return nm or "Unnamed project"


def quick_start(folder=None, files=None, recursive=True, parent=None, name=None):
    """Create a project (named after the photos unless a name is given) and begin reading them."""
    if S.running():
        raise ApiError("Processing is running. Stop it before starting another project.")
    if files:
        files = [os.path.normpath(f) for f in files if os.path.isfile(f)]
        if not files:
            raise ApiError("None of those files could be found.")
    elif not folder or not os.path.isdir(folder):
        raise ApiError("Folder not found: %s" % folder)
    parent = projects_dir(parent)
    name = (name or "").strip() or name_from_source(folder, files)
    try:
        os.makedirs(parent, exist_ok=True)
    except OSError as e:
        raise ApiError("Can't create the folder %s: %s" % (parent, e.strerror or e))
    d = unique_project_dir(parent, name)
    P.create_project(d, name)
    open_project(d)
    start_scan(folder, files, recursive)
    return d


def open_geotiff(path):
    import rasterio
    if not os.path.isfile(path):
        raise ApiError("File not found: %s" % path)
    with rasterio.open(path) as ds:
        if ds.crs is None or not ds.crs.is_projected:
            raise ApiError("That GeoTIFF isn't in a projected coordinate system (UTM or similar), "
                           "so it can't be measured or split. Reproject it first.")
        epsg = ds.crs.to_epsg()
        if not epsg:
            raise ApiError("PlaneSite couldn't identify the GeoTIFF's coordinate system (needs an EPSG code).")
        if ds.count < 3:
            raise ApiError("The GeoTIFF needs red, green and blue bands.")
        b = ds.bounds
        gsd = ds.res[0]
        try:
            units = float(ds.crs.linear_units_factor[1])
        except Exception:
            units = 1.0
    if abs(units - 1.0) > 1e-6:
        raise ApiError("Only GeoTIFFs in metres are supported (this one uses other units).")
    name = os.path.splitext(os.path.basename(path))[0]
    parent = projects_dir()
    d = unique_project_dir(parent, name)
    proj = P.create_project(d, name)
    proj["geotiff"] = {"path": os.path.normpath(path), "epsg": int(epsg), "gsd_cm": round(gsd * 100, 2)}
    proj["map_origin"] = {"epsg": int(epsg), "e": math.floor((b.left + b.right) / 2),
                          "n": math.floor((b.bottom + b.top) / 2)}
    P.save(d, proj)
    open_project(d)
    return d


def cached_feature_count(preset_name):
    from .pipeline import PRESETS
    pr = PRESETS.get(preset_name, PRESETS["balanced"])
    key = "r%d_n%d" % (pr["reduce"], pr["nfeat"])
    kp = os.path.join(L.work_dir(S.dir), "features", "key.json")
    try:
        with open(kp) as f:
            old = json.load(f)
    except Exception:
        return 0
    paths = set(m["path"] for m in S.proj["photos"])
    return sum(1 for v in old.values() if len(v) >= 2 and v[1] == key and v[0] in paths)


_EST_CACHE = {}


def project_estimate(settings):
    from . import estimate as E
    st = dict(S.proj["settings"])
    st.update(settings or {})
    photos = E.usable_photos({"photos": S.proj["photos"], "selection": S.proj.get("selection"),
                              "settings": st})
    if len(photos) < 3:
        return {"ok": False, "photos": len(photos)}
    sig = (len(photos), photos[0]["path"], photos[-1]["path"], st.get("max_oblique_deg"))
    with S.lock:
        if _EST_CACHE.get("sig") != sig:
            gsd_n, agl = E.native_gsd(photos)
            _EST_CACHE.clear()
            _EST_CACHE.update(sig=sig, area=E.covered_area_m2(photos, agl))
    return E.estimate({"photos": photos, "selection": None, "settings": st}, st,
                      cached_features=cached_feature_count(st.get("preset", "balanced")),
                      workers=st.get("workers"), area_m2=_EST_CACHE["area"])


def rename_project(name):
    """Rename the project; the folder follows the name when it was auto-named and nothing is busy."""
    if not name:
        raise ApiError("Enter a project name.")
    with S.lock:
        old_name = S.proj["name"]
        S.proj["name"] = name
        S.save()
        moved = False
        busy = S.running() or (S.scan and not S.scan.get("finished")) or (S.export and not S.export.get("finished"))
        base = os.path.basename(S.dir)
        auto = base == safe_name(old_name) or re.match(re.escape(safe_name(old_name)) + r"_\d+$", base)
        if not busy and auto and safe_name(name) != base:
            new_dir = unique_project_dir(os.path.dirname(S.dir), name)
            S.tile_local = threading.local()
            import gc
            gc.collect()
            for k in range(10):
                try:
                    os.rename(S.dir, new_dir)
                    moved = True
                    break
                except OSError:
                    time.sleep(0.2)
            if moved:
                S.cfg["recent"] = [r for r in S.cfg.get("recent", []) if os.path.normcase(r) != os.path.normcase(S.dir)]
                S.dir = new_dir
                S.remember(new_dir)
        return {"name": name, "dir": S.dir, "moved": moved}


def photo_points():
    if not S.proj or not S.origin:
        return {"points": [], "origin": None}
    from .geo import Geo
    epsg, e0, n0 = S.origin
    g = Geo(epsg)
    photos = S.proj["photos"]
    sel = set(S.proj["selection"]) if S.proj.get("selection") else None
    ok = [i for i, m in enumerate(photos) if m.get("lat") is not None]
    if not ok:
        return {"points": [], "origin": [e0, n0, epsg]}
    E, N = g.to_utm(np.array([photos[i]["lon"] for i in ok]), np.array([photos[i]["lat"] for i in ok]))
    pts = []
    maxob = S.proj["settings"].get("max_oblique_deg", 30)
    from .exif import camera_key
    cams = {}
    for m in photos:
        ck = camera_key(m)
        cams[ck] = cams.get(ck, 0) + 1
    main = max(cams.values()) if cams else 0
    for k, i in enumerate(ok):
        m = photos[i]
        obl = m.get("pitch") is not None and abs(m["pitch"] + 90) > maxob
        other = cams[camera_key(m)] < max(5, 0.2 * main)
        pts.append([round(float(E[k] - e0), 2), round(float(N[k] - n0), 2), i,
                    1 if (sel is None or i in sel) else 0, 1 if (m.get("rtk_flag") or 0) >= 50 else 0,
                    1 if obl else (2 if other else 0)])
    return {"points": pts, "origin": [e0, n0, epsg]}


def start_processing(settings):
    with S.lock:
        if S.running():
            raise ApiError("Processing is already running.")
        if not S.proj["photos"]:
            raise ApiError("Add photos first.")
        S.proj["settings"].update(settings or {})
        S.save()
        os.makedirs(L.data_dir(S.dir), exist_ok=True)
        prog = L.progress_file(S.dir)
        save_json(prog, {"status": "starting", "stage": "", "overall": 0, "message": "Starting", "elapsed": 0})
        logf = open(L.console_file(S.dir), "w")
        # CREATE_NO_WINDOW | BELOW_NORMAL_PRIORITY_CLASS: the workers inherit below-normal priority,
        # so they still get every idle core but the desktop and the PlaneSite window come first
        flags = (0x08000000 | 0x00004000) if IS_WIN else 0
        kw = {}
        if not IS_WIN:
            kw["start_new_session"] = True
        try:
            S.proc = subprocess.Popen([console_python(), RUN_SCRIPT, S.dir], cwd=APP_DIR, stdout=logf,
                                      stderr=subprocess.STDOUT, creationflags=flags, **kw)
        finally:
            logf.close()  # the child has its own handle; keeping ours would lock the project folder


def cancel_processing():
    with S.lock:
        if not S.running():
            return
        pid = S.proc.pid
        if IS_WIN:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True,
                           creationflags=0x08000000)
        else:
            import signal
            try:
                os.killpg(os.getpgid(pid), signal.SIGTERM)
            except Exception:
                S.proc.kill()
        try:
            S.proc.wait(10)
        except Exception:
            pass
        p = L.progress_file(S.dir)
        try:
            st = json.load(open(p))
        except Exception:
            st = {}
        st.update(status="cancelled", message="Cancelled")
        save_json(p, st)


def progress_state():
    if not S.dir:
        return None
    p = L.progress_file(S.dir)
    try:
        with open(p, "r") as f:
            st = json.load(f)
    except Exception:
        return None
    if st.get("status") in ("running", "starting") and not S.running():
        st["status"] = "error"
        st["message"] = st.get("message") or "Processing stopped unexpectedly. See the log."
    return st


# --------------------------------------------------------------------- areas
def areas_path():
    return L.areas_file(S.dir)


def load_areas():
    try:
        with open(areas_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_areas(areas):
    save_json(areas_path(), areas)


def areas_for_client(areas):
    from .export import area_stats, obstacle_parents
    epsg, e0, n0 = S.origin
    parents = obstacle_parents(areas)
    out = []
    for a in areas:
        rings = [[[round(p[0] - e0, 3), round(p[1] - n0, 3)] for p in r] for r in a["rings"]]
        st = area_stats(a)
        out.append({"id": a["id"], "name": a["name"], "kind": a.get("kind", ""), "role": a.get("role", "field"),
                    "rings": rings, "ha": float(st["ha"]), "ac": float(st["ac"]),
                    "ft2": round(float(st["ha"]) * 107639.104, 0)})
        if a.get("role") == "obstacle":
            out[-1]["parent"] = parents.get(a["id"])
        else:
            out[-1]["obstacles"] = sum(1 for v in parents.values() if v == a["id"])
        if a.get("pilot2"):
            out[-1]["pilot2"] = {k: a["pilot2"][k] for k in ("name", "sent") if k in a["pilot2"]}
    return out


def areas_from_client(lst):
    from .export import new_id
    epsg, e0, n0 = S.origin
    old = {a["id"]: a for a in load_areas()}
    out = []
    for a in lst:
        rings = [[[p[0] + e0, p[1] + n0] for p in r] for r in a["rings"]]
        for r in rings:
            if r[0] != r[-1]:
                r.append(list(r[0]))
        aid = a.get("id") or new_id()
        new = {k: v for k, v in old.get(aid, {}).items() if k not in ("id", "name", "kind", "rings", "role")}
        new.update({"id": aid, "name": a.get("name") or "Area", "kind": a.get("kind", "drawn"), "rings": rings})
        if a.get("role") == "obstacle":
            new["role"] = "obstacle"
        out.append(new)
    return out


# ------------------------------------------------------------------- plan before flying
def remember_place():
    """Keep where the open job is, as the starting point for planning the next one."""
    if not S.origin or not S.proj:
        return
    from .geo import Geo
    lon, lat = Geo(S.origin[0]).to_ll(S.origin[1], S.origin[2])
    S.cfg["last_place"] = {"lon": lon, "lat": lat, "name": S.proj.get("name", "")}


_FIELDS_CACHE = {}


def _project_fields(d):
    """Fields (not obstacles) of the project in folder d, with their obstacles, in lon/lat."""
    try:
        key = (os.path.getmtime(P.project_file(d)), os.path.getmtime(L.areas_file(d)))
    except OSError:
        key = None
    hit = _FIELDS_CACHE.get(d)
    if key and hit and hit[0] == key:
        return hit[1]
    res = _project_fields_read(d)
    if key:
        _FIELDS_CACHE[d] = (key, res)
    return res


def _project_fields_read(d):
    from .export import obstacle_parents, area_stats
    from .geo import Geo
    try:
        with open(P.project_file(d), "r", encoding="utf-8") as f:
            proj = json.load(f)
        with open(L.areas_file(d), "r", encoding="utf-8") as f:
            areas = json.load(f)
    except Exception:
        return None, []
    o = proj.get("map_origin") or {}
    epsg = (proj.get("geotiff") or {}).get("epsg") or o.get("epsg")
    if not epsg or not areas:
        return proj, []
    g = Geo(epsg)
    par = obstacle_parents(areas)
    out = []
    for a in areas:
        if a.get("role") == "obstacle":
            continue
        obs = [b for b in areas if par.get(b["id"]) == a["id"]]
        out.append({"area": a, "obstacles": obs, "epsg": int(epsg), "ac": area_stats(a)["ac"],
                    "center": g.to_ll(*np.mean(np.array(a["rings"][0], dtype=float), axis=0))})
    return proj, out


def field_library():
    """Fields from earlier projects (recent ones and everything in the projects folder), newest first."""
    seen, dirs = set(), []
    for d in S.cfg.get("recent", []):
        if os.path.normcase(d) not in seen:
            seen.add(os.path.normcase(d)); dirs.append(d)
    root = projects_dir()
    try:
        for n in os.listdir(root):
            d = os.path.join(root, n)
            if os.path.normcase(d) not in seen and os.path.isfile(P.project_file(d)):
                seen.add(os.path.normcase(d)); dirs.append(d)
    except OSError:
        pass
    out = []
    for d in dirs:
        if not os.path.isfile(L.areas_file(d)):
            continue
        proj, flds = _project_fields(d)
        mt = os.path.getmtime(L.areas_file(d))
        for f in flds:
            if f["area"].get("kind") == "grid":
                continue      # tiles of an ortho, not fields
            out.append({"dir": d, "project": (proj or {}).get("name") or os.path.basename(d), "id": f["area"]["id"],
                        "name": f["area"]["name"], "ac": round(float(f["ac"]), 2), "obstacles": len(f["obstacles"]),
                        "lon": round(f["center"][0], 6), "lat": round(f["center"][1], 6), "modified": mt})
    out.sort(key=lambda r: -r["modified"])
    return out[:300]


def plan_project(b):
    """A job that starts with planning the mapping flight: a project with no photos yet, whose map
    frame comes from where the field is. Photos are added after the flight."""
    from . import basemap
    from .export import read_boundaries, to_ortho_crs
    from pyproj import Transformer
    name = (b.get("name") or "").strip()
    if not name:
        raise ApiError("Enter a name for the job.")
    w = b.get("where") or {}
    kind = w.get("kind")
    new_areas = []
    if kind == "file":
        p = w.get("path") or ""
        if not os.path.isfile(p):
            raise ApiError("File not found: %s" % p)
        bnds, crs = read_boundaries(p)
        if not bnds:
            raise ApiError("No field outlines found in that file.")
        ll = to_ortho_crs([x for x in bnds if x.get("role") != "obstacle"] or bnds, crs, 4326)
        origin = basemap.origin_for(*basemap.lonlat_center([r for a in ll for r in a["rings"]]))
        new_areas = to_ortho_crs(bnds, crs, origin["epsg"])
        k = 0
        for a in new_areas:
            if a.get("role") == "obstacle":
                k += 1
                if re.match(r"^(Area \d+|.* \(\d+\))$", a.get("name") or ""):
                    a["name"] = "Obstacle %d" % k
    elif kind == "library":
        _, flds = _project_fields(w.get("dir") or "")
        f = next((x for x in flds if x["area"]["id"] == w.get("id")), None)
        if f is None:
            raise ApiError("That field is no longer in its project.")
        origin = basemap.origin_for(*f["center"])
        tr = Transformer.from_crs(f["epsg"], origin["epsg"], always_xy=True)
        from .export import new_id
        for a in [f["area"]] + f["obstacles"]:
            c = {"id": new_id(), "name": a["name"], "kind": a.get("kind", "drawn"),
                 "rings": [[list(map(float, tr.transform(p[0], p[1]))) for p in r] for r in a["rings"]]}
            if a.get("role") == "obstacle":
                c["role"] = "obstacle"
            elif (a.get("pilot2") or {}).get("settings"):
                c["pilot2"] = {"settings": a["pilot2"]["settings"]}      # same flight settings, not sent yet
            new_areas.append(c)
    elif kind == "point":
        try:
            lat, lon = float(w["lat"]), float(w["lon"])
        except (KeyError, TypeError, ValueError):
            raise ApiError("Find the field's location first.")
        origin = basemap.origin_for(lon, lat)
    else:
        raise ApiError("Choose where the field is.")
    parent = projects_dir(b.get("parent"))
    if S.running():
        raise ApiError("Processing is running. Wait for it to finish before starting another job.")
    d = unique_project_dir(parent, name)
    P.create_project(d, name)
    proj = P.load(d)
    proj["map_origin"] = origin
    proj["plan"] = {"created": time.strftime("%Y-%m-%d %H:%M"), "from": kind}
    P.save(d, proj)
    open_project(d)
    if new_areas:
        save_areas(new_areas)
    return {"dir": d, "fields": sum(1 for a in new_areas if a.get("role") != "obstacle")}


# ------------------------------------------------------------------- Pilot 2
def pilot2_settings():
    from . import pilot2
    try:
        has_key = bool(pilot2.load_key())
    except Exception:
        has_key = False
    d = dict(pilot2.DEFAULTS)
    d.update(S.cfg.get("pilot2") or {})
    return {"hub_url": S.cfg.get("hub_url") or pilot2.DEFAULT_HUB, "default_hub": pilot2.DEFAULT_HUB,
            "user": S.cfg.get("hub_user") or "", "has_key": has_key, "defaults": d}


def pilot2_set(b):
    from . import pilot2
    if "hub_url" in b:
        u = (b.get("hub_url") or "").strip().rstrip("/")
        if u and not re.match(r"^https?://[^\s/]+", u):
            raise ApiError("The hub address should start with https://")
        S.cfg["hub_url"] = u or pilot2.DEFAULT_HUB
    if "user" in b:
        S.cfg["hub_user"] = (b.get("user") or "").strip()[:60]
    if b.get("key") is not None and (b.get("key") or b.get("clear_key")):
        try:
            pilot2.save_key(b.get("key") or "")
        except OSError as e:
            raise ApiError(str(e))
    S.save_cfg()
    return pilot2_settings()


def _pilot2_area(b):
    from . import pilot2
    if not S.origin:
        raise ApiError("Open a project first.")
    area = next((a for a in load_areas() if a["id"] == b.get("id")), None)
    if area is None:
        raise ApiError("That field no longer exists.")
    if area.get("role") == "obstacle":
        raise ApiError("Obstacles can't be sent as a mapping mission. Send the field they are in.")
    given = dict(S.cfg.get("pilot2") or {})
    given.update((area.get("pilot2") or {}).get("settings") or {})
    given.update(b.get("settings") or {})
    try:
        s, ring, ring_ll, est, notes = pilot2.prepare(area, S.origin[0], given)
    except ValueError as e:
        raise ApiError(str(e))
    n_fields = sum(1 for a in load_areas() if a.get("role") != "obstacle")
    default_name = (area.get("pilot2") or {}).get("name") or (
        S.proj["name"] if n_fields == 1 else "%s - %s" % (S.proj["name"], area["name"]))
    name = pilot2.clean_name(b.get("name") or default_name)
    return area, s, ring_ll, est, notes, name


def pilot2_preview(b):
    area, s, ring_ll, est, notes, name = _pilot2_area(b)
    return {"settings": s, "estimates": est, "notes": notes, "name": name, "corners": len(ring_ll) - 1,
            "last": (area.get("pilot2") or {}).get("sent")}


def pilot2_send(b):
    """Write the plan-only KMZ (kept in the project's exports folder) and, unless only saving,
    upload it to the hub. Same mission name replaces the copy on the hub."""
    from . import pilot2
    area, s, ring_ll, est, notes, name = _pilot2_area(b)
    kmz = pilot2.build_kmz(ring_ll, s)
    out_dir = export_dir("Pilot 2")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, name + ".kmz")
    with open(path, "wb") as f:
        f.write(kmz)
    res = {"path": path, "name": name, "bytes": len(kmz), "estimates": est, "notes": notes}
    keep = {k: s[k] for k in pilot2.DEFAULTS}
    if b.get("upload", True):
        try:
            hub = pilot2.upload(S.cfg.get("hub_url") or pilot2.DEFAULT_HUB, pilot2.load_key(), kmz, name + ".kmz",
                                name=name, user=S.cfg.get("hub_user") or None)
        except (PermissionError, ConnectionError, RuntimeError) as e:
            raise ApiError(str(e))
        res["hub"] = hub
        sent = {"at": time.strftime("%Y-%m-%d %H:%M"), "hub_id": hub.get("id"), "replaced": bool(hub.get("replaced"))}
    else:
        sent = None
    # remember: these settings for this field, and as the starting point for new fields
    areas = load_areas()
    for a in areas:
        if a["id"] == area["id"]:
            rec = dict(a.get("pilot2") or {})
            rec.update({"settings": keep, "name": name})
            if sent:
                rec["sent"] = sent
            a["pilot2"] = rec
            res["pilot2"] = rec
    save_areas(areas)
    S.cfg["pilot2"] = {k: keep[k] for k in keep if k != "direction" or not keep["auto_direction"]}
    S.save_cfg()
    return res


def check_ortho_crs():
    """Areas are stored in the ortho CRS; the map frame uses the same UTM zone. A job planned before
    the flight can get its orthomosaic in another UTM zone (a field near a zone line): then the
    fields and the map frame move into the ortho's zone, staying on the same ground."""
    rep = S.report()
    if rep and S.origin and rep.get("epsg") != S.origin[0]:
        from pyproj import Transformer
        old, new = S.origin[0], int(rep["epsg"])
        tr = Transformer.from_crs(old, new, always_xy=True)
        e, n = tr.transform(S.origin[1], S.origin[2])
        areas = load_areas()
        for a in areas:
            a["rings"] = [[list(map(float, tr.transform(p[0], p[1]))) for p in r] for r in a["rings"]]
        if areas:
            save_areas(areas)
        S.proj["map_origin"] = {"epsg": new, "e": int(math.floor(e)), "n": int(math.floor(n))}
        S.save()
        S.compute_origin()


def save_diagnostics():
    """Zip the log, report (minus coordinates) and settings for troubleshooting / performance tuning."""
    import zipfile
    from .sysinfo import describe
    stamp = time.strftime("%Y%m%d-%H%M")
    path = os.path.join(S.dir, "PlaneSite-diagnostics-%s-%s.zip" % (safe_name(S.proj["name"]), stamp))
    rep = S.report() or {}
    rep = {k: v for k, v in rep.items() if k not in ("cam_positions", "center_lonlat")}
    summary = P.summarize(S.proj)
    info = {"version": __version__, "settings": S.proj.get("settings"), "photos": summary,
            "progress": progress_state(), "system": describe(S.dir, S.proj.get("folders") or [])}
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, fp in (("log.txt", L.log_file(S.dir)), ("process_console.txt", L.console_file(S.dir))):
            if os.path.exists(fp):
                z.write(fp, name)
        try:      # the app's own log (window freezes, server errors), last part only
            from .appwindow import data_dir
            lp = os.path.join(data_dir(), "logs", "planesite.log")
            with open(lp, "r", encoding="utf-8", errors="replace") as f:
                z.writestr("planesite.log", "".join(f.readlines()[-1500:]))
        except Exception:
            pass
        z.writestr("report.json", json.dumps(rep, indent=1))
        z.writestr("info.json", json.dumps(info, indent=1, default=str))
    return path


def export_worker(ids, out_dir, compression, scale=1.0, overviews=True, whole=False):
    from .export import export_area, safe_filename
    try:
        areas = [a for a in load_areas() if a["id"] in ids and a.get("role") != "obstacle"]
        if whole:
            areas = [None] + areas
        ortho = S.ortho_path()
        S.export.update(total=len(areas))
        os.makedirs(out_dir, exist_ok=True)
        pname = safe_name(S.proj["name"])
        used = set()
        for k, a in enumerate(areas):
            label = a["name"] if a else "Whole orthomosaic"
            S.export.update(current=label, done=k, frac=0)
            base = ("%s_%s" % (pname, safe_filename(a["name"]))) if a else "%s_orthomosaic" % pname
            if scale < 0.999:
                base += "_%dpct" % int(round(scale * 100))
            fn = base
            c = 2
            while fn.lower() in used:
                fn = "%s_%d" % (base, c)
                c += 1
            used.add(fn.lower())
            path = os.path.join(out_dir, fn + ".tif")
            try:
                export_area(ortho, a, path, compression=compression,
                            jpeg_quality=S.proj["settings"].get("jpeg_quality", 90),
                            progress=lambda f: S.export.update(frac=f), scale=scale, overviews=overviews)
                S.export["files"].append(path)
            except Exception as e:
                S.export["errors"].append("%s: %s" % (label, e))
        S.export.update(done=len(areas), finished=True, current="")
    except Exception as e:
        S.export.update(finished=True, error=str(e))


def basemap_prefetch():
    """Start fetching the satellite map around the job: its fields, the orthomosaic or the photos
    (or the planned spot), with a wide margin."""
    from . import basemap
    if not S.proj or not S.origin:
        return {"blocks": 0}
    _, e0, n0 = S.origin
    xs, ys = [], []
    for a in load_areas():
        for p in a["rings"][0]:
            xs.append(p[0] - e0); ys.append(p[1] - n0)
    op = S.ortho_path()
    if op:
        try:
            import rasterio
            with rasterio.open(op) as ds:
                bb = ds.bounds
            xs += [bb.left - e0, bb.right - e0]; ys += [bb.bottom - n0, bb.top - n0]
        except Exception:
            pass
    pts = [m for m in S.proj.get("photos") or [] if m.get("lat") is not None]
    if pts and not op:
        from .geo import Geo
        g = Geo(S.origin[0])
        for m in pts[:: max(1, len(pts) // 200)]:
            e, n = g.to_utm(m["lon"], m["lat"])
            xs.append(e - e0); ys.append(n - n0)
    if not xs:
        xs, ys = [0.0], [0.0]
    cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
    half = max(1000.0, 0.75 * max(max(xs) - min(xs), max(ys) - min(ys)))
    box = (cx - half, cy - half, cx + half, cy + half)
    return {"blocks": basemap.prefetch(L.basemap_dir(S.dir), S.origin, R0, box)}


# ------------------------------------------------------------------- publish map tiles
# Destinations are pluggable (planesite.publish): GitHub now, Cloudflare R2 later.
def _dest(b):
    from . import publish
    try:
        return publish.get(b.get("dest") or "github", S.cfg)
    except publish.PublishError as e:
        raise ApiError(str(e))


def _pub(fn, *a):
    from . import publish
    try:
        return fn(*a)
    except publish.PublishError as e:
        raise ApiError(str(e))


def publish_status(b):
    d = _dest(b)
    out = d.status()
    out["job"] = S.publish
    return out


def _pub_folder(b):
    """The tile folder to publish: one of this project's XAG tile maps, by name."""
    from . import xyztiles
    if not S.dir:
        raise ApiError("Open the project first.")
    m = xyztiles.repo_name(b.get("map") or "")
    folder = export_dir("XAG tiles", m)
    if not b.get("map") or not os.path.isdir(folder):
        raise ApiError("Make the XAG tiles for this project first.")
    return folder


def publish_check(b):
    from . import publish, xyztiles
    d = _dest(b)
    folder = _pub_folder(b)
    target = (b.get("target") or "").strip()
    if not target:
        raise ApiError("Choose where to publish.")
    name = xyztiles.repo_name(b.get("name") or os.path.basename(folder))
    summ = publish.folder_summary(folder)
    if not summ["tiles"]:
        raise ApiError("There are no tiles in this map yet. Make the XAG tiles first.")
    out = _pub(d.check, target, name, folder)
    out.update(summ)
    out.update({"name": name, "url": d.tile_url(target, name),
                "notes": xyztiles.github_notes(summ["bytes"], publishing=True) if d.id == "github" else []})
    return out


def publish_start(b):
    from . import xyztiles
    if S.publish and S.publish.get("running"):
        raise ApiError("A publish is already running.")
    d = _dest(b)
    folder = _pub_folder(b)
    target = (b.get("target") or "").strip()
    name = xyztiles.repo_name(b.get("name") or os.path.basename(folder))
    mode = b.get("mode") or "new"
    if mode not in ("new", "into", "into_force", "resume", "replace"):
        raise ApiError("Unknown publish mode.")
    job = {"running": True, "phase": "preparing", "part": 0, "parts": 0, "sent": 0, "total": 0, "error": None,
           "result": None, "dest": d.id, "target": target, "name": name, "folder": folder, "mode": mode,
           "cancel": False, "url": d.tile_url(target, name)}
    S.publish = job
    S.cfg.setdefault("publish", {})[d.id] = {"target": target}
    S.save_cfg()

    def work():
        from . import publish
        try:
            def prog(p):
                job.update({k: p[k] for k in ("phase", "part", "parts", "sent", "total") if k in p})
            res = d.publish(folder, target, name, mode, prog, lambda: job["cancel"])
            job["result"] = res
            if res.get("stopped"):
                job["phase"] = "stopped"
        except publish.PublishError as e:
            job["error"] = str(e)
        except Exception as e:
            traceback.print_exc()
            job["error"] = "%s: %s" % (type(e).__name__, e)
        finally:
            job["running"] = False
    threading.Thread(target=work, daemon=True).start()
    return {"ok": True}


# ------------------------------------------------------------------- XAG / XYZ map tiles
_XYZ_PLAN = {}

# Every export goes to a fixed folder inside the project, so it's always easy to find:
#   <project>/exports/GeoTIFF, /Boundaries/<software>, /XAG tiles/<map>, /Pilot 2
BND_DIRS = {"generic": "Other software", "dji_mapping": "DJI Pilot 2", "dji_agras": "DJI Agras",
            "xag": "XAG", "ceres": "Ceres"}


def export_dir(*parts):
    return L.exports_dir(S.dir, *parts)


def xyz_maps():
    """Tile maps made for this project: [{"name", "folder", "zooms"}], newest first."""
    root = export_dir("XAG tiles")
    out = []
    if os.path.isdir(root):
        for n in os.listdir(root):
            p = os.path.join(root, n)
            if os.path.isdir(p):
                zs = sorted(int(z) for z in os.listdir(p) if z.isdigit() and os.path.isdir(os.path.join(p, z)))
                if zs:
                    out.append({"name": n, "folder": p, "zooms": [zs[0], zs[-1]], "mtime": os.path.getmtime(p)})
    out.sort(key=lambda m: -m["mtime"])
    return out


def _xyz_plan(zmin, zmax):
    from . import xyztiles
    op = S.ortho_path()
    key = (op, os.path.getmtime(op))
    o = _XYZ_PLAN.get(key)
    if o is None:
        _XYZ_PLAN.clear()
        o = _XYZ_PLAN[key] = xyztiles._Ortho(op)
    return o, {z: len(o.tiles(z)) for z in range(zmin, zmax + 1)}


def _xyz_zooms(b):
    try:
        zmin, zmax = int(b.get("zmin", 14)), int(b.get("zmax", 20))
    except (TypeError, ValueError):
        raise ApiError("Enter whole numbers for the zoom levels.")
    if not (0 <= zmin <= zmax <= 23):
        raise ApiError("Zoom levels go from 0 to 23, and the first can't be above the last.")
    return zmin, zmax


def _xyz_tile(b):
    from . import xyztiles
    try:
        ts = int(b.get("tile") or xyztiles.TILE)
    except (TypeError, ValueError):
        ts = 0
    if ts not in xyztiles.TILE_SIZES:
        raise ApiError("Tile size must be 256 or 512 pixels.")
    return ts


def xyz_settings():
    from . import xyztiles
    if not S.proj or not S.ortho_path():
        raise ApiError("Open a project with an orthomosaic first.")
    rep = S.report() or {}
    last = S.cfg.get("xyz") or {}
    gsd = float(rep.get("gsd_cm") or 0) / 100.0
    lat = 30.0
    if S.origin:
        from .geo import Geo
        lat = Geo(S.origin[0]).to_ll(S.origin[1], S.origin[2])[1]
    # the zoom whose tiles are as sharp as the orthomosaic itself
    full = int(math.ceil(math.log2(156543.034 * math.cos(math.radians(lat)) / gsd))) if gsd > 0 else 20
    # the account the tiles will most likely be published to: the last Publish target
    # (not the account typed in the tiles window before 2.0: that was often the old Edko01)
    owner = ((S.cfg.get("publish") or {}).get("github") or {}).get("target") or "EdkoLLC"
    return {"name": xyztiles.repo_name(S.proj["name"]), "owner": owner,
            "parent": export_dir("XAG tiles"),
            "zmin": int(last.get("zmin", 14)), "zmax": int(last.get("zmax", 20)), "full_zoom": full,
            "tile": int(last.get("tile", xyztiles.TILE)), "maps": xyz_maps(),
            "m_px_z0": 156543.034 * math.cos(math.radians(lat)),
            "gsd_cm": rep.get("gsd_cm")}


def xyz_check(b):
    """Tiles to render for these zooms, and what's already in the folder."""
    from . import xyztiles
    if not S.proj or not S.ortho_path():
        raise ApiError("Open a project with an orthomosaic first.")
    zmin, zmax = _xyz_zooms(b)
    _, counts = _xyz_plan(zmin, zmax)
    name = xyztiles.repo_name(b.get("name") or S.proj["name"])
    root = export_dir("XAG tiles", name)
    old = [n for n in os.listdir(root) if n.isdigit()] if root and os.path.isdir(root) else []
    return {"name": name, "counts": counts, "total": sum(counts.values()), "folder": root,
            "existing_zooms": sorted(int(n) for n in old), "git": bool(root) and os.path.isdir(os.path.join(root, ".git")),
            "url": xyztiles.tile_url((b.get("owner") or "").strip(), name)}


def xyz_start(b):
    from . import xyztiles
    if not S.proj or not S.ortho_path():
        raise ApiError("Open a project with an orthomosaic first.")
    if S.export and not S.export.get("finished"):
        raise ApiError("An export is already running.")
    zmin, zmax = _xyz_zooms(b)
    parent = export_dir("XAG tiles")
    name = xyztiles.repo_name(b.get("name") or S.proj["name"])
    owner = (b.get("owner") or "").strip()
    root = os.path.join(parent, name)
    ts = _xyz_tile(b)
    S.cfg["xyz"] = {"owner": owner, "parent": parent, "zmin": zmin, "zmax": zmax, "tile": ts}
    S.save_cfg()
    _, counts = _xyz_plan(zmin, zmax)
    S.export = {"kind": "xyz", "done": 0, "total": sum(counts.values()), "current": "XAG tiles", "frac": 0,
                "files": [], "errors": [], "out_dir": root, "finished": False, "summary": None,
                "url": xyztiles.tile_url(owner, name), "name": name}
    op = S.ortho_path()

    def work():
        try:
            def prog(done, total, z):
                S.export.update(done=done, total=total, current="XAG tiles, zoom %d" % z)
            r = xyztiles.export(op, root, zmin, zmax, progress=prog, ts=ts)
            r["notes"] = xyztiles.github_notes(r["bytes"])
            S.export.update(summary=r, done=S.export["total"], current="", finished=True)
        except Exception as e:
            traceback.print_exc()
            S.export.update(finished=True, error=str(e))
    threading.Thread(target=work, daemon=True).start()
    return {"folder": root, "total": S.export["total"]}


def export_estimate(b):
    """Approximate output size for the export dialog."""
    from .export import area_stats
    op = S.ortho_path()
    if not op:
        return {"ok": False}
    import rasterio
    with rasterio.open(op) as ds:
        gsd = ds.res[0]
        src_jpeg = ds.compression is not None and ds.compression.value == "JPEG"
        W, H = ds.width, ds.height
    rep = S.report() or {}
    data_m2 = (rep.get("area_ha") or 0) * 1e4 or W * H * gsd * gsd
    scale = float(b.get("scale") or 1.0)
    comp = b.get("compression", "same")
    if comp == "same":
        comp = "jpeg" if src_jpeg else "deflate"
    bpp = 0.33 if comp == "jpeg" else 1.9
    ov = 1.33 if b.get("overviews", True) else 1.0
    m2 = data_m2 if b.get("whole") else 0.0
    ids = set(b.get("ids") or [])
    for a in load_areas():
        if a["id"] in ids:
            m2 += min(area_stats(a)["ha"] * 1e4, data_m2)
    px = m2 / (gsd / scale) ** 2
    return {"ok": True, "bytes": int(px * bpp * ov), "gsd_cm": round(gsd / scale * 100, 2),
            "megapixels": round(px / 1e6, 1), "native_gsd_cm": round(gsd * 100, 2)}


# ---------------------------------------------------------------------- tiles
os.environ.setdefault("GDAL_CACHEMAX", "512")   # MB of decoded GeoTIFF blocks shared by tile requests
TILE_CACHE_BYTES = 384 * 1024 * 1024


class _TileCache:
    """Finished map tiles (encoded bytes) for the open orthomosaic, least recently used dropped first."""

    def __init__(self):
        from collections import OrderedDict
        self.lock = threading.Lock()
        self.items = OrderedDict()
        self.bytes = 0
        self.key = None          # (path, mtime) the cached tiles belong to

    def get(self, key):
        with self.lock:
            v = self.items.get(key)
            if v is not None:
                self.items.move_to_end(key)
            return v

    def put(self, key, value):
        with self.lock:
            if key in self.items:
                return
            self.items[key] = value
            self.bytes += len(value[0]) + 64
            while self.bytes > TILE_CACHE_BYTES and self.items:
                _, old = self.items.popitem(last=False)
                self.bytes -= len(old[0]) + 64

    def reset(self, key):
        with self.lock:
            if self.key != key:
                self.items.clear()
                self.bytes = 0
                self.key = key


TILES = _TileCache()


def _tile_dataset(path, mt):
    import rasterio
    loc = S.tile_local
    if getattr(loc, "path", None) != path or getattr(loc, "mtime", None) != mt:
        if getattr(loc, "ds", None) is not None:
            loc.ds.close()
        loc.ds = rasterio.open(path)
        loc.path, loc.mtime = path, mt
    return loc.ds


_TILE_BUSY = [0]          # tiles being built for the screen right now
_LAST_TILE = [0.0]        # when the screen last asked for a tile
_TILE_BUSY_LOCK = threading.Lock()


def tile_png(z, x, y, prefetch=False):
    """Encoded map tile (bytes, content type) or None when the tile is empty. Fully covered tiles
    are JPEG (small and quick to make), tiles on the edge of the mosaic PNG with transparency."""
    path = S.ortho_path()
    if not path or not S.origin:
        return None
    mt = os.path.getmtime(path)
    TILES.reset((path, mt))
    key = (path, mt, z, x, y)
    hit = TILES.get(key)
    if hit is not None:
        return hit if hit[0] else None
    if prefetch and _TILE_BUSY[0] > 0:
        return "busy"          # the screen comes first; the browser will ask again when needed
    if not prefetch:
        _LAST_TILE[0] = time.time()
        with _TILE_BUSY_LOCK:
            _TILE_BUSY[0] += 1
    try:
        res = _make_tile(path, mt, z, x, y)
    finally:
        if not prefetch:
            with _TILE_BUSY_LOCK:
                _TILE_BUSY[0] -= 1
    TILES.put(key, res or (b"", ""))
    return res


def _make_tile(path, mt, z, x, y):
    import cv2
    from rasterio.enums import Resampling
    from rasterio.windows import Window
    ds = _tile_dataset(path, mt)
    _, e0, n0 = S.origin
    s = R0 / (2 ** z)
    te0 = e0 + x * 256 * s
    tn1 = n0 - y * 256 * s
    te1 = te0 + 256 * s
    tn0 = tn1 - 256 * s
    b = ds.bounds
    ie0, ie1 = max(te0, b.left), min(te1, b.right)
    in0, in1 = max(tn0, b.bottom), min(tn1, b.top)
    if ie1 <= ie0 or in1 <= in0:
        return None
    # destination rectangle inside the tile
    dx0 = int(round((ie0 - te0) / s))
    dx1 = int(round((ie1 - te0) / s))
    dy0 = int(round((tn1 - in1) / s))
    dy1 = int(round((tn1 - in0) / s))
    w, h = dx1 - dx0, dy1 - dy0
    if w <= 0 or h <= 0:
        return None
    gsd = ds.res[0]
    col0 = (ie0 - b.left) / gsd
    row0 = (b.top - in1) / gsd
    win = Window(col0, row0, (ie1 - ie0) / gsd, (in1 - in0) / gsd)
    rgb = ds.read([1, 2, 3], window=win, out_shape=(3, h, w), resampling=Resampling.bilinear)
    m = ds.read_masks(1, window=win, out_shape=(h, w), resampling=Resampling.nearest)
    if not m.any():
        return None
    if w == 256 and h == 256 and m.min() == 255:
        bgr = cv2.merge([rgb[2], rgb[1], rgb[0]])
        ok, enc = cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, 88])
        return enc.tobytes(), "image/jpeg"
    tile = np.zeros((256, 256, 4), np.uint8)
    tile[dy0:dy1, dx0:dx1, 0] = rgb[2]
    tile[dy0:dy1, dx0:dx1, 1] = rgb[1]
    tile[dy0:dy1, dx0:dx1, 2] = rgb[0]
    tile[dy0:dy1, dx0:dx1, 3] = m
    ok, enc = cv2.imencode(".png", tile, [cv2.IMWRITE_PNG_COMPRESSION, 1])
    return enc.tobytes(), "image/png"


_WARM = {"key": None}


def warm_tiles(bounds_local, maxz):
    """Build the zoomed-out tile levels in the background as soon as an orthomosaic is shown, so
    zooming and panning at overview scales never waits on the GeoTIFF. Stops if the ortho changes."""
    path = S.ortho_path()
    if not path or not S.origin:
        return
    mt = os.path.getmtime(path)
    key = (path, mt)
    if _WARM["key"] == key:
        return
    _WARM["key"] = key
    l, bot, r, top = bounds_local
    jobs = []
    for z in range(0, maxz + 1):
        s = R0 / (2 ** z) * 256
        xs = range(int(math.floor(l / s)), int(math.floor(r / s)) + 1)
        ys = range(int(math.floor(-top / s)), int(math.floor(-bot / s)) + 1)
        if len(xs) * len(ys) > 2500 or len(jobs) + len(xs) * len(ys) > 4000:
            break
        jobs += [(z, x, y) for y in ys for x in xs]

    def run(part):
        for z, x, y in part:
            if _WARM["key"] != key or S.ortho_path() != path:
                return
            while _TILE_BUSY[0] > 0 or time.time() - _LAST_TILE[0] < 0.4:
                time.sleep(0.05)       # the screen is loading tiles: step aside
            try:
                tile_png(z, x, y, prefetch=True)
            except Exception:
                return
    threading.Thread(target=run, args=(jobs,), daemon=True).start()


def _empty_png():
    import zlib, struct

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(b"\x00\x00\x00\x00\x00")) + chunk(b"IEND", b"")


EMPTY_PNG = _empty_png()


# -------------------------------------------------------------------- handler
class Handler(BaseHTTPRequestHandler):
    server_version = "PlaneSite/" + __version__
    protocol_version = "HTTP/1.1"     # keep connections open: the map loads many tiles in a row
    disable_nagle_algorithm = True    # else each kept-alive response waits ~40 ms for a delayed ACK

    def log_message(self, fmt, *args):
        pass

    def handle(self):
        try:
            super().handle()
        except _GONE:
            pass      # the window dropped the request (closed, reloaded, or a tile scrolled away)

    def _send(self, code, body, ctype="application/json", headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        headers = dict(headers or {})
        self.send_header("Cache-Control", headers.pop("Cache-Control", None)
                         or ("no-store" if ctype == "application/json" else "max-age=60"))
        for k, v in headers.items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        try:
            u = urlparse(self.path)
            path = u.path
            q = parse_qs(u.query)
            if path.startswith("/api/"):
                S.last_seen = time.time()
                if S.win_state == "closed":
                    S.win_state = "visible"  # reloaded, or another window took over
                return self._send(200, self.api_get(path, q))
            m = re.match(r"^/tiles/(\d+)/(-?\d+)/(-?\d+)\.png$", path)
            if m:
                pf = "pf" in q
                res = tile_png(int(m.group(1)), int(m.group(2)), int(m.group(3)), prefetch=pf)
                if res == "busy":
                    return self._send(503, b"", "text/plain", {"Cache-Control": "no-store"})
                data, ctype = res or (EMPTY_PNG, "image/png")
                # the URL carries the ortho's modification time, so a tile never changes
                return self._send(200, data, ctype, {"Cache-Control": "max-age=31536000, immutable"})
            m = re.match(r"^/basemap/(-?\d+)/(-?\d+)/(-?\d+)$", path)
            if m:
                from . import basemap
                res = None
                if S.dir and S.origin:
                    res = basemap.tile(L.basemap_dir(S.dir), int(m.group(1)), int(m.group(2)),
                                       int(m.group(3)), S.origin, R0)
                if res == basemap.ERROR:          # couldn't reach the image service: the window retries
                    return self._send(503, b"", "text/plain", {"Cache-Control": "no-store"})
                if not res:
                    return self._send(200, EMPTY_PNG, "image/png", {"Cache-Control": "max-age=86400"})
                return self._send(200, res[0], res[1], {"Cache-Control": "max-age=31536000, immutable"})
            if path == "/thumb":
                d = (q.get("dir") or [""])[0]
                ok = any(os.path.normcase(d) == os.path.normcase(r) for r in S.cfg.get("recent", []))
                p = os.path.join(L.processing_dir(d), "preview.png")
                if ok and os.path.exists(p):
                    with open(p, "rb") as f:
                        return self._send(200, f.read(), "image/png")
                return self._send(404, b"", "text/plain")
            if path == "/preview.png":
                p = os.path.join(S.outputs(), "preview.png") if S.dir else None
                if p and os.path.exists(p):
                    with open(p, "rb") as f:
                        return self._send(200, f.read(), "image/png")
                return self._send(404, b"", "text/plain")
            if path in ("/", ""):
                path = "/index.html"
            fp = os.path.normpath(os.path.join(WEB_DIR, path.lstrip("/")))
            if not fp.startswith(WEB_DIR) or not os.path.isfile(fp):
                return self._send(404, "Not found", "text/plain")
            ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
            if fp.endswith(".js"):
                ctype = "text/javascript"
            elif fp.endswith(".webmanifest"):
                ctype = "application/manifest+json"
            with open(fp, "rb") as f:
                data = f.read()
            if fp.endswith(".html"):
                data = data.replace(b"{{VERSION}}", __version__.encode())
            if fp.endswith((".html", ".js", ".css", ".webmanifest")):
                # always fresh after an update; the files are local so this costs nothing
                return self._send(200, data, ctype, {"Cache-Control": "no-cache"})
            return self._send(200, data, ctype)
        except ApiError as e:
            self._send(400, {"error": str(e)})
        except _GONE:
            pass
        except Exception as e:
            traceback.print_exc()
            try:
                self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})
            except _GONE:
                pass

    def do_POST(self):
        try:
            u = urlparse(self.path)
            body = json_body(self)
            self._send(200, self.api_post(u.path, body) or {"ok": True})
        except ApiError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:
            traceback.print_exc()
            self._send(500, {"error": "%s: %s" % (type(e).__name__, e)})

    # ------------------------------------------------------------------ GET
    def api_get(self, path, q):
        if path == "/api/status":
            return {"version": __version__, "project": project_summary(),
                    "recent": [r for r in S.cfg.get("recent", []) if os.path.exists(P.project_file(r))],
                    "default_dir": projects_dir(),
                    "running": S.running() if S.dir else False, "progress": progress_state(),
                    "scan": S.scan, "export": S.export, "platform": sys.platform,
                    "update": dict(updater.state)}
        if path == "/api/publish/status":
            return publish_status({"dest": (q.get("dest") or ["github"])[0]})
        if path == "/api/xyz/settings":
            return xyz_settings()
        if path == "/api/plan/start":
            lp = S.cfg.get("last_place")
            return {"last": lp, "dir": projects_dir()}
        if path == "/api/fields/library":
            return {"fields": field_library()}
        if path == "/api/projects":
            return {"projects": recent_projects(), "dir": projects_dir()}
        if path == "/api/pilot2/settings":
            return pilot2_settings()
        if path == "/api/update/check":
            info = updater.check()
            info.pop("_download", None)
            return info
        if not S.proj:
            raise ApiError("No project is open.")
        if path == "/api/photos":
            return photo_points()
        if path == "/api/log":
            p = L.log_file(S.dir)
            if not os.path.exists(p):
                return {"lines": []}
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                lines = f.read().splitlines()
            return {"lines": lines[-int(q.get("tail", ["300"])[0]):]}
        if path == "/api/result":
            rep = S.report()
            op = S.ortho_path()
            if not rep or not op:
                return {"ready": False}
            check_ortho_crs()
            import rasterio
            with rasterio.open(op) as ds:
                b = ds.bounds
                gsd = ds.res[0]
            _, e0, n0 = S.origin
            # finest tile level: no finer than the mosaic itself (allowing ~1.2x); beyond that the
            # browser enlarges the last level instead of the server making upsampled tiles
            maxz = int(math.floor(math.log2(R0 / gsd) + 0.27))
            rep = dict(rep)
            cams = rep.pop("cam_positions", [])
            warm_tiles((b.left - e0, b.bottom - n0, b.right - e0, b.top - n0), maxz)
            return {"ready": True, "report": rep, "ortho_path": op, "outputs_dir": S.outputs(),
                    "bounds": [b.left - e0, b.bottom - n0, b.right - e0, b.top - n0], "max_native_zoom": maxz,
                    "cams": [[round(c[0] - e0, 2), round(c[1] - n0, 2)] for c in cams],
                    "mtime": os.path.getmtime(op), "r0": R0}
        if path == "/api/areas/outlines/settings":
            return {"last": S.cfg.get("outlines") or {}, "dirs": {k: export_dir("Boundaries", v) for k, v in BND_DIRS.items()}}
        if path == "/api/areas":
            return {"areas": areas_for_client(load_areas())}
        if path == "/api/estimate":
            st = {}
            if q.get("preset"):
                st["preset"] = q["preset"][0]
            if q.get("res_factor"):
                st["res_factor"] = float(q["res_factor"][0])
                st["resolution_cm"] = None
            if q.get("compression"):
                st["compression"] = q["compression"][0]
            if q.get("gpu"):
                st["gpu"] = q["gpu"][0]
            return project_estimate(st)
        raise ApiError("Unknown request")

    # ----------------------------------------------------------------- POST
    def api_post(self, path, b):
        if path == "/api/window":
            st = str(b.get("state", ""))
            if st in ("visible", "hidden", "closed"):
                S.win_state = st
                S.last_seen = time.time()
            return {}
        if path == "/api/browse":
            return {"path": browse(b.get("mode", "folder"), b.get("title", "Select"), b.get("initial", ""))}
        if path == "/api/clientlog":
            msg = str(b.get("msg", ""))[:2000]
            print("window: %s" % msg)
            if S.dir and S.running():
                try:
                    with open(L.log_file(S.dir), "a", encoding="utf-8") as f:
                        f.write("[%s] window: %s\n" % (time.strftime("%H:%M:%S"), msg[:500]))
                except OSError:
                    pass
            return {}
        if path == "/api/quit":
            if S.dir and S.running():
                if not b.get("force"):
                    raise ApiError("Processing is running.")
                cancel_processing()
            threading.Timer(0.3, lambda: os._exit(0)).start()
            return {}
        if path == "/api/update/install":
            busy = None
            if S.dir and S.running():
                busy = "Processing is running. Let it finish or cancel it before updating."
            elif S.export and not S.export.get("finished"):
                busy = "An export is running. Wait for it to finish before updating."
            elif S.scan and not S.scan.get("finished"):
                busy = "Photos are still being read. Wait a moment before updating."
            try:
                info = updater.install(busy)
            except RuntimeError as e:
                raise ApiError(str(e))
            return {"version": info["latest"]}
        if path == "/api/project/new":
            name = (b.get("name") or "").strip()
            if not name:
                raise ApiError("Enter a project name.")
            parent = projects_dir(b.get("parent"))
            d = os.path.join(parent, safe_name(name))
            if os.path.exists(P.project_file(d)):
                raise ApiError("A project with that name already exists in %s." % parent)
            P.create_project(d, name)
            open_project(d)
            return {"dir": d}
        if path == "/api/basemap/prefetch":
            return basemap_prefetch()
        if path == "/api/publish/signin":
            return _pub(_dest(b).start_signin)
        if path == "/api/publish/signout":
            _dest(b).signout()
            return {}
        if path == "/api/publish/targets":
            return _pub(_dest(b).targets)
        if path == "/api/publish/app":
            S.cfg["github_app"] = {"client_id": (b.get("client_id") or "").strip(), "slug": (b.get("slug") or "").strip()}
            S.save_cfg()
            return _dest({"dest": "github"}).status()
        if path == "/api/publish/check":
            return publish_check(b)
        if path == "/api/publish/start":
            return publish_start(b)
        if path == "/api/publish/cancel":
            if S.publish and S.publish.get("running"):
                S.publish["cancel"] = True
            return {}
        if path == "/api/xyz/check":
            return xyz_check(b)
        if path == "/api/xyz/export":
            return xyz_start(b)
        if path == "/api/plan/new":
            return plan_project(b)
        if path == "/api/locate":
            from . import basemap
            try:
                return basemap.locate(b.get("q"))
            except ValueError as e:
                raise ApiError(str(e))
        if path == "/api/project/start":
            d = quick_start(b.get("folder"), b.get("files") or None, b.get("recursive", True), b.get("parent"),
                            b.get("name"))
            return {"dir": d}
        if path == "/api/project/suggest":
            files = [f for f in (b.get("files") or []) if f]
            folder = b.get("folder") or None
            parent = projects_dir(b.get("parent"))
            name = (b.get("name") or "").strip() or name_from_source(folder, files or None)
            n_files = len(files)
            return {"name": name, "parent": parent, "dir": unique_project_dir(parent, name), "files": n_files}
        if path == "/api/geotiff/open":
            return {"dir": open_geotiff(b.get("path") or "")}
        if path == "/api/projects_dir":
            p = b.get("path") or ""
            if not p:
                raise ApiError("Choose a folder.")
            p = projects_dir(p)
            os.makedirs(p, exist_ok=True)
            S.cfg["projects_dir"] = p
            S.save_cfg()
            return {"path": p}
        if path == "/api/recent/forget":
            S.cfg["recent"] = [r for r in S.cfg.get("recent", []) if r != b.get("dir")]
            S.save_cfg()
            return {}
        if path == "/api/project/open":
            open_project(b.get("dir", ""))
            return {"dir": S.dir}
        if path == "/api/project/close":
            if S.running():
                raise ApiError("Processing is running.")
            S.dir = S.proj = None
            S.scan = S.export = None
            return {}
        if path == "/api/open_url":
            u = b.get("url") or ""
            if not re.match(r"^https?://", u):
                raise ApiError("Not a web address.")
            import webbrowser
            webbrowser.open(u)
            return {}
        if path == "/api/open_path":
            p = b.get("path") or (S.dir if S.dir else "")
            if p and b.get("make") and S.dir and os.path.normpath(p).startswith(os.path.normpath(S.dir)):
                os.makedirs(p, exist_ok=True)
            if p and os.path.exists(p):
                open_in_explorer(p)
            return {}
        if not S.proj:
            raise ApiError("No project is open.")
        if path == "/api/photos/add":
            if S.proj.get("geotiff"):
                raise ApiError("This project shows an imported GeoTIFF. Start a new project for photos.")
            files = b.get("files") or None
            folder = None if files else os.path.normpath(b.get("folder") or "")
            start_scan(folder, files, b.get("recursive", True))
            return {}
        if path == "/api/photos/remove_folder":
            folder = b.get("folder")
            nf = os.path.normcase(os.path.normpath(folder))
            S.proj["photos"] = [m for m in S.proj["photos"]
                                if not os.path.normcase(os.path.normpath(m["path"])).startswith(nf + os.sep)
                                and os.path.normcase(os.path.dirname(m["path"])) != nf]
            S.proj["folders"] = [f for f in S.proj["folders"] if f != folder]
            S.proj["selection"] = None
            if not S.proj.get("plan"):       # a planned job keeps the frame its fields were drawn in
                S.proj.pop("map_origin", None)
            S.compute_origin()
            S.save()
            return {}
        if path == "/api/photos/select":
            if b.get("clear"):
                S.proj["selection"] = None
            else:
                ids = b.get("ids") or []
                S.proj["selection"] = sorted(set(int(i) for i in ids)) or None
            S.save()
            return {}
        if path == "/api/diagnostics":
            p = save_diagnostics()
            if IS_WIN:
                subprocess.Popen(["explorer", "/select,", p])
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", p])          # show it selected in Finder
            else:
                open_in_explorer(os.path.dirname(p))
            return {"path": p}
        if path == "/api/settings":
            S.proj["settings"].update(b)
            S.save()
            return {}
        if path == "/api/rename":
            return rename_project((b.get("name") or "").strip())
        if path == "/api/process/start":
            start_processing(b.get("settings"))
            return {}
        if path == "/api/process/cancel":
            cancel_processing()
            return {}
        if path == "/api/pilot2/settings":
            return pilot2_set(b)
        if path == "/api/pilot2/preview":
            return pilot2_preview(b)
        if path == "/api/pilot2/send":
            return pilot2_send(b)
        if path == "/api/areas":
            save_areas(areas_from_client(b.get("areas", [])))
            return {"areas": areas_for_client(load_areas())}
        if path == "/api/areas/import":
            from .export import read_boundaries, to_ortho_crs
            p = b.get("path") or ""
            if not os.path.isfile(p):
                raise ApiError("File not found: %s" % p)
            bnds, crs = read_boundaries(p)
            if not bnds:
                raise ApiError("No polygons found in that file.")
            role = b.get("role") or "auto"      # "field", "obstacle" or "auto" (the file's own tags)
            for x in bnds:
                if role == "obstacle" or (role == "auto" and x.get("role") == "obstacle"):
                    x["role"] = "obstacle"
                else:
                    x.pop("role", None)
            new = to_ortho_crs(bnds, crs, S.origin[0])
            # obstacles that came without a name of their own get "Obstacle N"
            k = sum(1 for a in load_areas() if a.get("role") == "obstacle")
            for a in new:
                if a.get("role") == "obstacle":
                    k += 1
                    if re.match(r"^(Area \d+|.* \(\d+\))$", a.get("name") or "Area 1"):
                        a["name"] = "Obstacle %d" % k
            areas = load_areas() + new
            save_areas(areas)
            n_obs = sum(1 for a in new if a.get("role") == "obstacle")
            return {"areas": areas_for_client(areas), "added": len(new) - n_obs, "obstacles": n_obs}
        if path == "/api/areas/grid":
            from .export import grid_areas
            op = S.ortho_path()
            if not op:
                raise ApiError("Process the photos first.")
            new = grid_areas(op, b.get("mode", "size"), float(b.get("size_m") or 250), int(b.get("rows") or 2),
                             int(b.get("cols") or 2), b.get("prefix") or "Grid")
            areas = load_areas() + new
            save_areas(areas)
            return {"areas": areas_for_client(areas), "added": len(new)}
        if path == "/api/areas/outlines":
            from .export import export_outlines
            ids = set(b.get("ids") or [])
            if not ids:
                raise ApiError("Choose at least one field.")
            out_dir = export_dir("Boundaries", BND_DIRS.get(b.get("target") or "generic", "Other software"))
            S.cfg["outlines"] = {k: b.get(k) for k in ("target", "format", "per_field", "obstacles", "spray", "xag_geojson")}
            S.save_cfg()
            try:
                files = export_outlines(load_areas(), ids, S.origin[0], out_dir, b.get("target") or "generic",
                                        fmt=b.get("format") or "kml", per_field=bool(b.get("per_field", True)),
                                        obstacles=bool(b.get("obstacles", True)),
                                        base=safe_name(S.proj["name"]), spray=b.get("spray"),
                                        xag_geojson=bool(b.get("xag_geojson")))
            except ValueError as e:
                raise ApiError(str(e))
            return {"files": files, "dir": out_dir}
        if path == "/api/areas/kml":
            from .export import areas_to_kml
            areas = [a for a in load_areas() if not b.get("ids") or a["id"] in b["ids"]]
            out_dir = export_dir("Boundaries", "Other software")
            os.makedirs(out_dir, exist_ok=True)
            p = os.path.join(out_dir, "%s_areas.kml" % safe_name(S.proj["name"]))
            with open(p, "w", encoding="utf-8") as f:
                f.write(areas_to_kml(areas, S.origin[0]))
            return {"path": p}
        if path == "/api/export/estimate":
            return export_estimate(b)
        if path == "/api/export":
            if not S.ortho_path():
                raise ApiError("Process the photos first.")
            if S.export and not S.export.get("finished"):
                raise ApiError("An export is already running.")
            ids = b.get("ids") or []
            whole = bool(b.get("whole"))
            if not ids and not whole:
                raise ApiError("Choose the whole orthomosaic or at least one area to export.")
            scale = float(b.get("scale") or 1.0)
            if not 0.05 <= scale <= 1.0:
                raise ApiError("Scale must be between 5 and 100%.")
            out_dir = export_dir("GeoTIFF")
            S.export = {"done": 0, "total": len(ids) + (1 if whole else 0), "current": "", "frac": 0,
                        "files": [], "errors": [], "out_dir": out_dir, "finished": False}
            threading.Thread(target=export_worker,
                             args=(ids, out_dir, b.get("compression", "same"), scale,
                                   bool(b.get("overviews", True)), whole), daemon=True).start()
            return {}
        raise ApiError("Unknown request")


def _window_trace(browser, state):
    """Note in the log when an open window stops asking for updates (it polls every 1-3 s) and
    when it starts again, so a frozen window leaves a trace."""
    if not S.last_seen:
        return
    idle = time.time() - S.last_seen
    if idle > 15 and not state.get("quiet"):
        state["quiet"] = S.last_seen
        pr = progress_state() or {}
        print("%s window stopped checking in at %s (processing: %s, %s)" % (
            time.strftime("%H:%M:%S"), time.strftime("%H:%M:%S", time.localtime(S.last_seen)),
            bool(S.dir and S.running()), pr.get("message", "")))
    elif idle < 5 and state.get("quiet"):
        print("%s window responding again after %.0f s" % (time.strftime("%H:%M:%S"), time.time() - state["quiet"]))
        state["quiet"] = 0


_GONE = (ConnectionAbortedError, ConnectionResetError, BrokenPipeError)


def lifetime_watch(srv, browser):
    """Quit when the app window is gone and nothing is running."""
    started = time.time()
    trace = {}
    last_tick = time.time()
    grace_until = 0.0
    while True:
        time.sleep(5)
        now = time.time()
        if now - last_tick > 60:
            # The computer was asleep: the window hasn't been able to check in either. Give it
            # time to wake up and reconnect instead of closing straight away.
            print("%s computer was asleep for %.0f min" % (time.strftime("%H:%M:%S"), (now - last_tick) / 60))
            grace_until = now + 120
            if S.last_seen:
                S.last_seen = now
        last_tick = now
        try:
            _window_trace(browser, trace)
        except Exception:
            pass
        if now < grace_until:
            continue
        busy = (S.dir and S.running()) or (S.scan and not S.scan.get("finished")) \
            or (S.export and not S.export.get("finished")) \
            or (S.publish and S.publish.get("running")) \
            or updater.state.get("phase") in ("downloading", "installing", "restarting")
        if busy:
            continue
        idle = time.time() - S.last_seen
        if browser is not None and browser.poll() is None:
            continue  # our app window is still open (possibly minimised)
        if S.last_seen == 0:
            if browser is not None and time.time() - started > 120:
                break  # window closed before the page ever loaded
            continue
        # 20 s after our own window closes; longer when the window is a normal browser tab (no
        # Chrome / Edge app window, e.g. Safari on a Mac) or after an update restart, where the open
        # window reconnects within seconds. A hidden tab polls rarely or not at all, so it gets hours;
        # a page that said it was closed gets a few seconds to reload.
        if S.win_state == "hidden":
            limit = 8 * 3600
        elif S.win_state == "closed":
            limit = 15
        else:
            limit = 20 if browser is not None else 90
        if idle > limit:
            break
    print("%s No window open and nothing running - closing PlaneSite." % time.strftime("%H:%M:%S"))
    os._exit(0)


def serve(port=8765, open_browser=True):
    srv = None
    for p in range(port, port + 30):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), Handler)
            port = p
            break
        except OSError:
            continue
    if srv is None:
        raise SystemExit("Could not find a free local port.")
    srv.daemon_threads = True
    updater.PORT[0] = port
    url = "http://127.0.0.1:%d/" % port
    print("PlaneSite %s is running at %s" % (__version__, url))
    browser = None
    if open_browser:
        from .appwindow import open_window
        browser = open_window(url)
    threading.Thread(target=lifetime_watch, args=(srv, browser), daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
