"""Open PlaneSite in its own app window (Microsoft Edge / Chrome app mode), and find a running instance."""
import json
import os
import subprocess
import sys
import urllib.request

IS_WIN = sys.platform == "win32"
PORTS = range(8765, 8795)


def data_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
    d = os.path.join(base, "PlaneSite")
    os.makedirs(d, exist_ok=True)
    return d


def find_running():
    """URL of an already running PlaneSite server, or None."""
    for p in PORTS:
        url = "http://127.0.0.1:%d/" % p
        try:
            with urllib.request.urlopen(url + "api/status", timeout=0.4) as r:
                if "PlaneSite" in (r.headers.get("Server") or ""):
                    json.loads(r.read().decode("utf-8"))
                    return url
        except Exception:
            continue
    return None


def _browser_candidates():
    c = []
    if IS_WIN:
        try:
            import winreg
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for exe in ("msedge.exe", "chrome.exe"):
                    try:
                        k = winreg.OpenKey(hive, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\%s" % exe)
                        c.append(winreg.QueryValue(k, None))
                    except OSError:
                        pass
        except Exception:
            pass
        for env in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
            base = os.environ.get(env)
            if base:
                c.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
                c.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
    else:
        for exe in ("microsoft-edge", "google-chrome", "chromium", "chromium-browser"):
            for d in os.environ.get("PATH", "").split(os.pathsep):
                c.append(os.path.join(d, exe))
    seen = []
    for p in c:
        if p and os.path.isfile(p) and p not in seen:
            seen.append(p)
    return seen


# The window is a browser page; keep the browser from pausing or slowing it when it is covered,
# in the background or the computer is busy processing (Edge's efficiency mode / tab freezing).
WINDOW_FLAGS = [
    "--disable-renderer-backgrounding",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-features=Translate,CalculateNativeWinOcclusion,IntensiveWakeUpThrottling",
    # Draw the window without the graphics card. Processing keeps the NVIDIA card busy with long
    # rendering work, and on laptops the browser's own GPU drawing can stall behind it, leaving
    # the window frozen while PlaneSite keeps running. The map and panels draw fine in software.
    "--disable-gpu",
]


def open_window(url):
    """Open url as a standalone app window. Returns the browser Popen (or None if a normal tab was used)."""
    profile = os.path.join(data_dir(), "window")
    for exe in _browser_candidates():
        try:
            return subprocess.Popen([exe, "--app=" + url, "--user-data-dir=" + profile, "--start-maximized",
                                     "--no-first-run", "--no-default-browser-check"] + WINDOW_FLAGS,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            continue
    import webbrowser
    webbrowser.open(url)
    return None


# ------------------------------------------------------------------ Windows shortcuts
DESCRIPTION = "Drone mapping and spray mission planning"     # the shortcuts' tooltip; the installer uses the same text


def refresh_shortcuts():
    """Bring the tooltip of existing PlaneSite shortcuts (desktop, Start menu) up to date, so a
    change of wording reaches computers that installed an earlier version. Best effort, quiet,
    and only touches shortcuts named PlaneSite.lnk that point at this installation."""
    if sys.platform != "win32":
        return
    target = os.path.normcase(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    ps = (
        "$d = '%s'; $t = '%s'; $s = New-Object -ComObject WScript.Shell;"
        "foreach ($f in @('Desktop','CommonDesktopDirectory','Programs','CommonPrograms')) {"
        " $p = Join-Path ([Environment]::GetFolderPath($f)) 'PlaneSite.lnk';"
        " if (Test-Path $p) { $l = $s.CreateShortcut($p);"
        "  if ($l.TargetPath.ToLower().StartsWith($t) -and $l.Description -ne $d) { $l.Description = $d; $l.Save() } } }"
    ) % (DESCRIPTION.replace("'", "''"), target.replace("'", "''"))
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=60,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       creationflags=0x08000000)       # CREATE_NO_WINDOW
    except Exception:
        pass
